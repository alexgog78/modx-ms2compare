<?php

$prefix = 'ms2compare_list_';

$_lang[$prefix . 'default'] = 'Список сравнения по умолчанию';
