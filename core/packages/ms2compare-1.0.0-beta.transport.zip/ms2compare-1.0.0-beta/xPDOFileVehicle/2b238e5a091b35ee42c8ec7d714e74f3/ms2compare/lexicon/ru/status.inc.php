<?php

$prefix = 'ms2compare_';

$_lang[$prefix . 'scs_add'] = 'Товар добавлен в сравнение';
$_lang[$prefix . 'scs_remove'] = 'Товар удален из сравнения';
$_lang[$prefix . 'scs_clear'] = 'Список сравнения очищен';

$_lang[$prefix . 'err_response_format'] = 'Неверный формат ответа';
$_lang[$prefix . 'err_action_nf'] = 'Дейсвие не найдено: "[[+action]]"';
