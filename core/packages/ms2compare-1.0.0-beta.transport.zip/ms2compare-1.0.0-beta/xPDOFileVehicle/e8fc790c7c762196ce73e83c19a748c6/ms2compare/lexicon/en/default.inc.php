<?php

//TODO
$prefix = 'ms2compare_';
$_lang['ms2compare'] = 'Сравнение товаров';

$_lang[$prefix . 'desc'] = 'Сравнение товаров miniShop2';
$_lang[$prefix . 'add'] = 'Добавить в сравнение';
$_lang[$prefix . 'remove'] = 'Удалить из сравнения';
$_lang[$prefix . 'clear'] = 'Очистить список сравнения';
$_lang[$prefix . 'count'] = 'Товаров';
$_lang[$prefix . 'is_empty'] = 'Список сравнения пуст';
$_lang[$prefix . 'options_all'] = 'Все параметры';
$_lang[$prefix . 'options_diff'] = 'Различающиеся';
