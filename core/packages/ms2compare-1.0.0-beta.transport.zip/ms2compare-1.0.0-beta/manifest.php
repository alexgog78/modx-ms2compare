<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Compare.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Compare
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Compare
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f937328948aecc77a78269b6a23cea53',
      'native_key' => 'ms2compare',
      'filename' => 'modNamespace/a62fca8fad4d6fcfe8a163df152b51b2.vehicle',
      'namespace' => 'ms2compare',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fab4c154e75aaa092826f7f7ced22ba0',
      'native_key' => 'fab4c154e75aaa092826f7f7ced22ba0',
      'filename' => 'xPDOFileVehicle/2b238e5a091b35ee42c8ec7d714e74f3.vehicle',
      'namespace' => 'ms2compare',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c225d418f44c84ba8462fc71c0342bbb',
      'native_key' => 'c225d418f44c84ba8462fc71c0342bbb',
      'filename' => 'xPDOFileVehicle/2dc952a56d93049fc877cae64decca31.vehicle',
      'namespace' => 'ms2compare',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e368d0ba5ea9260aafa97f96e45e9024',
      'native_key' => 'ms2compare_check_context',
      'filename' => 'modSystemSetting/cd9cec1d3937d6012b4341e52b6c1f77.vehicle',
      'namespace' => 'ms2compare',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9ff2949328b3d2d139455459cdf361',
      'native_key' => 'ms2compare_frontend_css',
      'filename' => 'modSystemSetting/10957a46c720e4897a422a1ff0d29712.vehicle',
      'namespace' => 'ms2compare',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd105c5c763531e7f88ff247d87de1e3',
      'native_key' => 'ms2compare_frontend_js',
      'filename' => 'modSystemSetting/bdc7bd4973feba10c44cbdfda5762e9e.vehicle',
      'namespace' => 'ms2compare',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '650de1318926210dd68fbba30e0a456b',
      'native_key' => 0,
      'filename' => 'modChunk/ff4b1b680a1bf511070bdb3a858e8198.vehicle',
      'namespace' => 'ms2compare',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'cd0f4b052a558cb6a1e6d5899f6eef5e',
      'native_key' => 0,
      'filename' => 'modChunk/b35e0f59a01220ed70d761dd465c3c16.vehicle',
      'namespace' => 'ms2compare',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'cdd1063f1806b2c29da92615b607b237',
      'native_key' => 0,
      'filename' => 'modChunk/e2b451eaba75976f913854f11ec58a84.vehicle',
      'namespace' => 'ms2compare',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '7413f0bb196263e1da9ad893e6beb8b6',
      'native_key' => 0,
      'filename' => 'modSnippet/677a450d8df937e3c94e7eee11fbca0b.vehicle',
      'namespace' => 'ms2compare',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '442660f1bc7746632aeb97a20459bc7f',
      'native_key' => 0,
      'filename' => 'modSnippet/0977ec4b6a165c47c3dadd248b750183.vehicle',
      'namespace' => 'ms2compare',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '1b8c5d8d733c4d841f1096bfec6fed42',
      'native_key' => 0,
      'filename' => 'modSnippet/df7df2217615c6952c807485d0d10302.vehicle',
      'namespace' => 'ms2compare',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'e5dd8d148ac001e6a8f638bbf3553d91',
      'native_key' => 0,
      'filename' => 'modPlugin/69bf81c0cf46fc060a532f6b3912ae80.vehicle',
      'namespace' => 'ms2compare',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '984285b6fe639f45f5fa5530d2c95e47',
      'native_key' => 1,
      'filename' => 'modCategory/3cf41a8cd4a203e1ad43add148b23a8a.vehicle',
      'namespace' => 'ms2compare',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4ddc615062c79f20dcc2557d0a958f36',
      'native_key' => '4ddc615062c79f20dcc2557d0a958f36',
      'filename' => 'xPDOScriptVehicle/7a6fdca50de6dbce9fc0c70218b2a7c5.vehicle',
      'namespace' => 'ms2compare',
    ),
  ),
);