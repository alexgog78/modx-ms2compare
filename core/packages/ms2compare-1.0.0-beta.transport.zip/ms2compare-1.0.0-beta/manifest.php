<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Compare.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Compare
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Compare
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '879dfe28fd81578fd346f66041130e1f',
      'native_key' => 'ms2compare',
      'filename' => 'modNamespace/fe4971ed48b383f9cd57d52977dac54d.vehicle',
      'namespace' => 'ms2compare',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '2fb591dcca93777264d37c34b25bce18',
      'native_key' => '2fb591dcca93777264d37c34b25bce18',
      'filename' => 'xPDOFileVehicle/e8fc790c7c762196ce73e83c19a748c6.vehicle',
      'namespace' => 'ms2compare',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ac468bf51242f02c5c812d40504b96f6',
      'native_key' => 'ac468bf51242f02c5c812d40504b96f6',
      'filename' => 'xPDOFileVehicle/859b9e47259418fb2fbb035e94c8c94d.vehicle',
      'namespace' => 'ms2compare',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cc235de26576194ef47b51b97ae65a1',
      'native_key' => 'ms2compare_check_context',
      'filename' => 'modSystemSetting/a0721f39c1d28499bc2ba3062171c7c4.vehicle',
      'namespace' => 'ms2compare',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2ca3b575c01434bf999aa54897da33e',
      'native_key' => 'ms2compare_frontend_css',
      'filename' => 'modSystemSetting/9c8659841d0a5f01fc70fc666911d964.vehicle',
      'namespace' => 'ms2compare',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a88465aa7c42226e064ba4afe99955a1',
      'native_key' => 'ms2compare_frontend_js',
      'filename' => 'modSystemSetting/58b60a7947d6ba5258ed46e719a65eb6.vehicle',
      'namespace' => 'ms2compare',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '67ffd57ef2f7a6024e810d0b85a84cb3',
      'native_key' => 0,
      'filename' => 'modChunk/bdea6a7875265e32aa4826eaee432e81.vehicle',
      'namespace' => 'ms2compare',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'da7df6c01d8994f6f4affa5930da49b4',
      'native_key' => 0,
      'filename' => 'modChunk/9e66bd61cfcaceabf0f199dac172a76d.vehicle',
      'namespace' => 'ms2compare',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '41853406c3cab04752b664e02d72bd63',
      'native_key' => 0,
      'filename' => 'modChunk/34071c5cf4c85cfea1bf02a927fcb83f.vehicle',
      'namespace' => 'ms2compare',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'bdeb9b015c66f66e11daf0df0e042697',
      'native_key' => 0,
      'filename' => 'modSnippet/9c05263383593e01d9a2460dfb267e0f.vehicle',
      'namespace' => 'ms2compare',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'ac13bfcc64e8b3a7bfe5b84aa10ea008',
      'native_key' => 0,
      'filename' => 'modSnippet/2cbc8872cf3d016332c46fea45d75b80.vehicle',
      'namespace' => 'ms2compare',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '074e6d40dc40533b9c62d4cd6e28625f',
      'native_key' => 0,
      'filename' => 'modSnippet/a9e2c772664d1f7d3dd7fcdabb07d978.vehicle',
      'namespace' => 'ms2compare',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '610a0e1e11bfa1d99a87ef0c70f12d7a',
      'native_key' => 0,
      'filename' => 'modPlugin/01900d4acf1bf49777ee6909dfe5d11c.vehicle',
      'namespace' => 'ms2compare',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6799200ead6c49dd3021ee67b0894992',
      'native_key' => 1,
      'filename' => 'modCategory/800dbc7ff757b3e17479736c70239535.vehicle',
      'namespace' => 'ms2compare',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '50023347d15895a0a46441ea7631a472',
      'native_key' => '50023347d15895a0a46441ea7631a472',
      'filename' => 'xPDOScriptVehicle/bf165c6a0f37df57964f5920c15c5762.vehicle',
      'namespace' => 'ms2compare',
    ),
  ),
);